<template>
<section id="destinations" class="destinations">
  <div class="heading-row"><div><p class="eyebrow">CURATED FOR YOU</p><h2>Where will you go next?</h2></div><router-link to="/flights">View all flights <span>→</span></router-link></div>
  <div class="cards">
    <article class="card" v-for="place in places" :key="place.name" @click="viewFlight(place.name)">
      <div class="image"><img :src="place.image" :alt="place.name"><span class="tag">{{place.country}}</span></div>
      <div class="body"><div><h3>{{place.name}}</h3><p>{{place.description}}</p></div><span class="arrow">↗</span></div>
    </article>
  </div>
</section>
</template>
<script setup>
import {useRouter} from 'vue-router'
const router=useRouter()
const places=[
{name:'Paris',country:'France',image:'/paris.jpg',description:'Art, iconic streets and unforgettable evenings.'},
{name:'Cairo',country:'Egypt',image:'/Cairo.webp',description:'Ancient wonders, the Nile and endless energy.'},
{name:'Dubai',country:'UAE',image:'/Dubai.webp',description:'Skyline views, desert adventures and luxury.'},
{name:'Tokyo',country:'Japan',image:'/Tokyo.jpg',description:'A vibrant blend of tradition and tomorrow.'},
{name:'Marrakech',country:'Morocco',image:'/marrakech.jpg',description:'Colorful souks, warm hospitality and culture.'}
]
async function viewFlight(city){try{const r=await fetch(`http://localhost:3000/api/flights?to=${encodeURIComponent(city)}`);const f=await r.json();if(f.length)router.push(`/flights/${f[0].id}`);else router.push('/flights')}catch(e){router.push('/flights')}}
</script>
<style scoped>
.destinations{padding:120px clamp(22px,7vw,96px) 90px;background:#f7fafb}.heading-row{display:flex;justify-content:space-between;align-items:end;gap:20px;margin-bottom:30px}.eyebrow{color:var(--teal);font-size:10px;font-weight:800;letter-spacing:1.8px;margin:0 0 9px}.heading-row h2{font-family:'Plus Jakarta Sans';font-size:clamp(28px,4vw,42px);letter-spacing:-1.5px;margin:0}.heading-row>a{font-size:13px;font-weight:800;text-decoration:none;color:var(--ink)}.heading-row>a span{color:var(--teal);margin-left:8px}.cards{display:grid;grid-template-columns:repeat(12,1fr);gap:18px}.card{grid-column:span 4;background:#fff;border:1px solid var(--border);border-radius:18px;overflow:hidden;box-shadow:0 8px 25px rgba(11,31,51,.045);cursor:pointer;transition:.3s}.card:nth-child(4),.card:nth-child(5){grid-column:span 6}.card:hover{transform:translateY(-6px);box-shadow:var(--shadow)}.image{height:205px;position:relative;overflow:hidden}.image img{width:100%;height:100%;object-fit:cover;transition:.5s}.card:hover .image img{transform:scale(1.06)}.tag{position:absolute;left:14px;top:14px;background:rgba(255,255,255,.9);padding:6px 10px;border-radius:99px;font-size:10px;font-weight:800}.body{padding:18px;display:flex;justify-content:space-between;gap:12px}.body h3{font-family:'Plus Jakarta Sans';margin:0 0 6px;font-size:18px}.body p{margin:0;color:var(--muted);font-size:12px;line-height:1.55}.arrow{width:34px;height:34px;border-radius:10px;background:#eef8f9;color:var(--teal);display:grid;place-items:center;flex-shrink:0;font-size:17px}@media(max-width:760px){.cards{display:grid;grid-template-columns:1fr}.card,.card:nth-child(4),.card:nth-child(5){grid-column:auto}.heading-row{align-items:start;flex-direction:column}}
</style>
