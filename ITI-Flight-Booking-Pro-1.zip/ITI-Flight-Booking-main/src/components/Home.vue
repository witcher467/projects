<template>
<section id="top" class="hero">
  <div class="hero-bg"></div>
  <div class="hero-content">
    <div class="hero-copy">
      <div class="pill"><span>✦</span> SMARTER WAY TO TRAVEL</div>
      <h1>Make your next<br><em>escape unforgettable.</em></h1>
      <p>Compare flights, discover beautiful destinations, and book your next journey with confidence.</p>
      <div class="hero-actions">
        <router-link to="/flights" class="primary">Explore flights <span>→</span></router-link>
        <a class="play" href="#destinations" @click.prevent="scrollDest">Discover destinations <b>↓</b></a>
      </div>
    </div>
    <div class="trust">
      <div class="avatars"><span>✈</span><span>★</span><span>+</span></div>
      <div><strong>Simple booking</strong><small>Built for better journeys</small></div>
    </div>
  </div>

  <form id="search" class="search-panel" @submit.prevent="searchFlights">
    <div class="search-title"><span class="search-icon">⌕</span><div><b>Find your flight</b><small>Search by route & date</small></div></div>
    <div class="field"><label>From</label><div class="input-wrap"><span>●</span><input v-model="fromsearch" placeholder="Departure city" @input="selectedFrom=false"><div v-if="fromsearch&&!selectedFrom" class="suggestions"><button type="button" v-for="c in fromcountrys" :key="c.name" @click="selectFrom(c)">{{c.name}}</button></div></div></div>
    <div class="swap">⇄</div>
    <div class="field"><label>To</label><div class="input-wrap"><span>●</span><input v-model="tosearch" placeholder="Where to?" @input="selectedTo=false"><div v-if="tosearch&&!selectedTo" class="suggestions"><button type="button" v-for="c in tocountrys" :key="c.name" @click="selectTo(c)">{{c.name}}</button></div></div></div>
    <div class="field date-field"><label>Departure</label><div class="input-wrap"><span>◷</span><input type="date" v-model="departureDate"></div></div>
    <button class="search-btn" type="submit">Search <span>→</span></button>
  </form>
</section>
</template>

<script setup>
import {computed,onMounted,ref} from 'vue'
import {useRouter} from 'vue-router'
const router=useRouter(),fromsearch=ref(''),tosearch=ref(''),departureDate=ref(''),countrys=ref([]),selectedFrom=ref(false),selectedTo=ref(false)
async function getcountrys(){try{const [d,f]=await Promise.all([fetch('http://localhost:3000/api/destinations'),fetch('http://localhost:3000/api/flights')]);countrys.value=await d.json();(await f.json()).forEach(x=>{if(!countrys.value.some(c=>c.name===x.from))countrys.value.push({name:x.from});if(!countrys.value.some(c=>c.name===x.to))countrys.value.push({name:x.to})})}catch(e){console.error(e)}}
onMounted(getcountrys)
const filter=(s)=>countrys.value.filter(c=>c.name.toLowerCase().startsWith(s.value.toLowerCase()))
const fromcountrys=computed(()=>filter(fromsearch)),tocountrys=computed(()=>filter(tosearch))
function selectFrom(c){fromsearch.value=c.name;selectedFrom.value=true} function selectTo(c){tosearch.value=c.name;selectedTo.value=true}
function scrollDest(){document.getElementById('destinations')?.scrollIntoView({behavior:'smooth'})}
async function searchFlights(){if(!fromsearch.value||!tosearch.value||!departureDate.value){alert('Please select From, To and Departure date.');return}try{const r=await fetch('http://localhost:3000/api/flights');const flights=await r.json();const results=flights.filter(f=>f.from.trim().toLowerCase()===fromsearch.value.trim().toLowerCase()&&f.to.trim().toLowerCase()===tosearch.value.trim().toLowerCase()&&f.departure.split('T')[0]===departureDate.value);localStorage.setItem('searchResults',JSON.stringify(results));localStorage.setItem('searchData',JSON.stringify({from:fromsearch.value,to:tosearch.value,date:departureDate.value}));router.push('/flights')}catch(e){alert('Could not load flights. Please try again.')}}
</script>

<style scoped>
.hero{position:relative;min-height:690px;padding:80px clamp(22px,7vw,96px) 38px;color:#fff;overflow:visible;display:flex;flex-direction:column;justify-content:space-between}
.hero-bg{position:absolute;inset:0;background:linear-gradient(100deg,rgba(5,22,38,.91) 0%,rgba(5,22,38,.66) 48%,rgba(5,22,38,.2) 100%),url('../assets/Flightbg.jpeg') center/cover;z-index:0}
.hero-content{position:relative;z-index:1;max-width:650px;padding-top:22px}
.pill{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.22);padding:8px 12px;border-radius:99px;font-size:10px;letter-spacing:1.5px;font-weight:800}
.pill span{color:#7de2eb}
h1{font-family:'Plus Jakarta Sans';font-size:clamp(45px,6.2vw,78px);line-height:1.02;letter-spacing:-3px;margin:22px 0 18px}
h1 em{font-style:normal;color:#76d9e2}
.hero-copy>p{max-width:510px;font-size:17px;line-height:1.7;color:#d7e4eb;margin:0}
.hero-actions{display:flex;align-items:center;gap:24px;margin-top:30px}
.primary{background:var(--coral);color:#fff;text-decoration:none;padding:14px 19px;border-radius:12px;font-weight:800;font-size:14px;box-shadow:0 12px 30px rgba(255,107,95,.22)}
.primary span{margin-left:12px}.play{text-decoration:none;font-weight:700;font-size:13px;color:#eaf4f7}.play b{margin-left:9px;color:#7de2eb}
.trust{display:flex;gap:12px;align-items:center}.avatars{display:flex}.avatars span{width:32px;height:32px;border-radius:50%;background:#e5f5f6;color:var(--teal);display:grid;place-items:center;border:2px solid rgba(255,255,255,.8);margin-left:-7px;font-size:11px}.avatars span:first-child{margin-left:0}.trust strong,.trust small{display:block}.trust strong{font-size:12px}.trust small{color:#b8cbd4;margin-top:3px;font-size:11px}
.search-panel{position:relative;z-index:5;width:100%;max-width:1250px;background:#fff;color:var(--ink);border:1px solid rgba(255,255,255,.7);border-radius:18px;padding:15px 17px;display:grid;grid-template-columns:1.1fr 1.25fr 22px 1.25fr 1.15fr auto;gap:10px;align-items:center;box-shadow:0 25px 55px rgba(0,0,0,.2);margin:0 auto -62px}
.search-title{display:flex;align-items:center;gap:10px;padding:5px 8px}.search-title b,.search-title small{display:block}.search-title b{font-size:13px}.search-title small{color:var(--muted);font-size:10px;margin-top:2px}.search-icon{width:34px;height:34px;border-radius:10px;background:#e9f7f8;color:var(--teal);display:grid;place-items:center;font-size:22px}.field{min-width:0}.field label{display:block;color:#8a98a5;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:1px;margin:0 0 4px}.input-wrap{position:relative;display:flex;align-items:center;gap:7px;border:1px solid var(--border);border-radius:10px;padding:0 10px;height:44px}.input-wrap>span{font-size:9px;color:var(--teal)}input{border:0;outline:0;width:100%;color:var(--ink);background:transparent;font-size:12px}.suggestions{position:absolute;left:0;right:0;top:49px;background:#fff;border:1px solid var(--border);border-radius:10px;box-shadow:var(--shadow);padding:5px;z-index:20}.suggestions button{display:block;width:100%;text-align:left;background:#fff;border:0;padding:9px;border-radius:7px;font-size:12px}.suggestions button:hover{background:#f1f7f8}.swap{width:22px;height:22px;border-radius:50%;background:#eef8f9;color:var(--teal);display:grid;place-items:center;font-size:12px;margin-top:17px}.search-btn{height:44px;border:0;border-radius:10px;background:var(--ink);color:#fff;padding:0 20px;font-weight:800;font-size:12px}.search-btn span{color:#7de2eb;margin-left:8px}
@media(max-width:900px){.hero{min-height:760px}.search-panel{grid-template-columns:1fr 1fr;margin-bottom:-60px}.search-title{grid-column:1/-1}.swap{display:none}.search-btn{grid-column:1/-1}.date-field{grid-column:1/-1}}
@media(max-width:520px){.hero{padding-top:55px}.hero-content{padding-top:0}h1{letter-spacing:-2px}.hero-copy>p{font-size:15px}.hero-actions{flex-wrap:wrap}.search-panel{grid-template-columns:1fr}.search-title,.date-field,.search-btn{grid-column:auto}.search-panel{margin-left:-4px;margin-right:-4px;width:calc(100% + 8px)}}
</style>
