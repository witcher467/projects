<template>
<nav class="navbar">
  <router-link class="logo" to="/" aria-label="UFLY home">
    <span class="logo-mark">U</span><span>FLY</span>
  </router-link>
  <div class="nav-links">
    <router-link to="/">Home</router-link>
    <a href="/#destinations" @click.prevent="scrollToSection('destinations')">Destinations</a>
    <router-link to="/flights">Flights</router-link>
    <router-link to="/Mybooking">My Bookings</router-link>
  </div>
  <router-link class="nav-action" to="/flights">Explore flights <span>↗</span></router-link>
  <button class="menu-btn" @click="open=!open" aria-label="Toggle navigation">☰</button>
  <div v-if="open" class="mobile-menu">
    <router-link @click="open=false" to="/">Home</router-link>
    <a @click="scrollAndClose('destinations')">Destinations</a>
    <router-link @click="open=false" to="/flights">Flights</router-link>
    <router-link @click="open=false" to="/Mybooking">My Bookings</router-link>
  </div>
</nav>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
const router=useRouter(),route=useRoute(),open=ref(false)
function scrollToSection(id){
  if(route.path!=='/'){router.push('/').then(()=>requestAnimationFrame(()=>document.getElementById(id)?.scrollIntoView({behavior:'smooth'})))}
  else document.getElementById(id)?.scrollIntoView({behavior:'smooth'})
}
function scrollAndClose(id){open.value=false;scrollToSection(id)}
</script>

<style scoped>
.navbar{height:78px;padding:0 clamp(22px,5vw,72px);display:flex;align-items:center;gap:42px;background:rgba(255,255,255,.96);position:sticky;top:0;z-index:50;border-bottom:1px solid rgba(229,237,242,.8);backdrop-filter:blur(14px)}
.logo{text-decoration:none;display:flex;align-items:center;gap:9px;font-family:'Plus Jakarta Sans';font-weight:800;font-size:20px;letter-spacing:1.5px}
.logo-mark{width:35px;height:35px;border-radius:11px;display:grid;place-items:center;background:linear-gradient(135deg,var(--teal),#21a7b7);color:#fff;box-shadow:0 7px 18px rgba(11,114,133,.25)}
.nav-links{display:flex;gap:28px;flex:1}
.nav-links a,.mobile-menu a{font-size:14px;font-weight:600;text-decoration:none;color:#607083;transition:.2s}
.nav-links a:hover,.nav-links a.router-link-active{color:var(--ink)}
.nav-action{background:var(--ink);color:#fff;text-decoration:none;padding:11px 17px;border-radius:12px;font-size:13px;font-weight:700}
.nav-action span{margin-left:7px;color:#7de2eb}
.menu-btn,.mobile-menu{display:none}
@media(max-width:760px){.navbar{gap:15px}.nav-links,.nav-action{display:none}.menu-btn{display:block;margin-left:auto;border:0;background:#f2f6f8;border-radius:10px;padding:9px 12px;color:var(--ink)}.mobile-menu{display:grid;position:absolute;top:68px;right:18px;left:18px;background:#fff;padding:14px;border:1px solid var(--border);border-radius:15px;box-shadow:var(--shadow);gap:4px}.mobile-menu a{padding:12px}}
</style>
