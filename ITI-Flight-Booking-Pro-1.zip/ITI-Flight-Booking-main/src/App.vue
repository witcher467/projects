<script setup>
import Navbar from './components/Navbar.vue'
import Footer from './components/Footer.vue'
</script>

<template>
  <div class="app-shell">
    <Navbar />
    <main><router-view /></main>
    <Footer />
  </div>
</template>

<style scoped>
.app-shell{max-width:1480px;margin:0 auto;background:#fff;min-height:100vh;box-shadow:0 0 70px rgba(11,31,51,.08)}
</style>
